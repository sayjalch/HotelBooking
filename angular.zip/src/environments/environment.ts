export const environment={
  firebase: {
    projectId: 'hotel-booking-c3db8',
    appId: '1:57401440439:web:b14526b9e33f2f73bf7532',
    storageBucket: 'hotel-booking-c3db8.appspot.com',
    apiKey: 'AIzaSyDAJx7avSF4z-WBEPQv3Ull-mat_aLMzFc',
    authDomain: 'hotel-booking-c3db8.firebaseapp.com',
    messagingSenderId: '57401440439',
  },
  production:false
}