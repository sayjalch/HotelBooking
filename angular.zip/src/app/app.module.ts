import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatNativeDateModule } from '@angular/material/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RoomBookingComponent } from './room-booking/room-booking.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MatStepperModule, MatStep } from '@angular/material/stepper';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';
import { NgImageSliderModule } from 'ng-image-slider';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { HotelsComponent } from './hotels/hotels.component';
import { RoomsComponent } from './rooms/rooms.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DialogComponent } from './dialog/dialog.component';
import { MatRippleModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { HotelPolicyComponent } from './hotel-policy/hotel-policy.component';
import { MatMenuModule } from '@angular/material/menu';
import { CheckInCheckOutComponent } from './check-in-check-out/check-in-check-out.component';
import { MatTabsModule } from '@angular/material/tabs';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { EmployeesComponent } from './employees/employees.component';
import { HomeComponent } from './home/home.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { HotelroomsComponent } from './hotelrooms/hotelrooms.component';
import { RoominfoComponent } from './roominfo/roominfo.component';
import { LoginFormComponent } from './login-form/login-form.component'
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { initializeApp,provideFirebaseApp } from '@angular/fire/app';
import { environment } from '../environments/environment';
import { provideAuth,getAuth } from '@angular/fire/auth';

@NgModule({
  declarations: [
    AppComponent,
    RoomBookingComponent,
    HomeDashboardComponent,
    HotelPolicyComponent,
    DialogComponent,
    HotelsComponent,
    RoomsComponent,
    CheckInCheckOutComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    EmployeesComponent,
    HomeComponent,
    EnquiryComponent,
    HotelroomsComponent,
    RoominfoComponent,
    LoginFormComponent,
    RegistrationFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatListModule,
    MatExpansionModule,
    MatRadioModule,
    MatDatepickerModule,
    DatePipe,
    MatNativeDateModule,
    HttpClientModule,
    MatStepperModule,
    NgImageSliderModule,
    MatDividerModule,
    MatCardModule,
    MatCheckboxModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    NgImageSliderModule,
    MatToolbarModule,
    MatExpansionModule,
    MatDialogModule,
    MatTooltipModule,
    MatRippleModule,
    MatChipsModule,
    MatMenuModule,
    MatTabsModule,
    MatSidenavModule,
    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideAuth(() => getAuth())
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
