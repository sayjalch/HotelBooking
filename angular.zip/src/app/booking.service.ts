import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from 'src/model/booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  constructor(public http: HttpClient) { }
  url: string = "http://localhost:3000";

  saveBooking(book: Booking) {
    return this.http.post<Booking>(this.url + "/saveBookingDetails", book);
  }

  getBookingDetails(): Observable<Booking[]> {
    return this.http.get<Booking[]>(this.url + "/saveBookingDetails/");
  }

  updateBookingData(book: Booking): Observable<Booking> {
    return this.http.patch<Booking>(this.url + "/saveBookingDetails/" + book.id, book);
  }

  updateBookingCheckout(book: Booking, id: string) {
    return this.http.put<Booking>(this.url + "/saveBookingDetails/" + id, book);
  }
}
