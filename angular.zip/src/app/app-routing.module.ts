import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoomsComponent } from './rooms/rooms.component';
import { HotelsComponent } from './hotels/hotels.component';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';
import { RoomBookingComponent } from './room-booking/room-booking.component';
import { EmployeesComponent } from './employees/employees.component';
import { HomeComponent } from './home/home.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { HotelroomsComponent } from './hotelrooms/hotelrooms.component';
import { RoominfoComponent } from './roominfo/roominfo.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';

const routes: Routes = [
  {path:"hotels",component:HotelsComponent},
  {path:"rooms/:id",component:RoomsComponent},
  {path:"home",component:HomeDashboardComponent},
  {path:"booking/:id",component:RoomBookingComponent},
  {path:"UserDashboard",component:UserDashboardComponent},
  {path:"adminHome",component:HomeComponent},
  {
    path: 'employees',
    component: EmployeesComponent,
  },
  {
    path: 'enquiry',
    component: EnquiryComponent,
  },
  {
    path: 'hotelrooms',
    component: HotelroomsComponent,
  },
  {
    path: 'roominfo',
    component: RoominfoComponent,
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
