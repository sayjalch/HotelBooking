import { Component,OnInit } from '@angular/core';
import { AdminserviceService } from '../adminservice.service';

@Component({
  selector: 'app-hotelrooms',
  templateUrl: './hotelrooms.component.html',
  styleUrls: ['./hotelrooms.component.css']
})
export class HotelroomsComponent implements OnInit {

  constructor(private api:AdminserviceService){}

  ngOnInit(): void {
    this.getAllHotelsInfo();
  }
  hoteldata !:any;
  getAllHotelsInfo()
  {
    this.api.getHotelsInfo()
    .subscribe(res=>{
      this.hoteldata = res;
      
    })
  }
}
