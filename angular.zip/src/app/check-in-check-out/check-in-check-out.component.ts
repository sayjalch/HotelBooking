import { Component } from '@angular/core';
import { Booking } from 'src/model/booking';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'
import { BookingService } from '../booking.service';
import { Room } from 'src/model/room-form';
import { CommonServiceService } from './../common-service.service';

@Component({
  selector: 'app-check-in-check-out',
  templateUrl: './check-in-check-out.component.html',
  styleUrls: ['./check-in-check-out.component.css']
})
export class CheckInCheckOutComponent {

  book = new Booking();
  minDate = new Date();
  checkInCheckOutForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, public b: BookingService, private cs: CommonServiceService, public datepipe: DatePipe) {
  }

  ngOnInit() {
    this.checkInCheckOutForm = new FormGroup({
      id: new FormControl(''),
      fullName: new FormControl(['']),
      mobileNo: new FormControl(['']),
      checkIn: new FormControl(['', Validators.required]),
      mobileNumSearch: new FormControl(['']),
    });

    this.totalAmount = 0;
    this.foodTotal = 0;
    this.foodPrice = 0;
    this.booking = [];
    this.bevTotal = 0;
    this.bevragePrice = 0;
    this.quantity = 1;
    this.bevQuantity = 1;

    this.checkoutform = this.fb.group({
      searchMobleno: ['', [Validators.required]],
      fullName: [''],
      mobileNo: [''],
      //mobiletxt:['',[Validators.required]],
      roomName: [''],
      roomType: [''],
      checkIn: [''],
      roomNo: [''],
      price: [''],
      foodPrice: [''],
      quantity: [''],
      total: [''],
      foodPricetxt: [''],
      foodQuantity: [''],
      foodTotaltxt: [''],
      chkBev: [''],
      bevragePricetxt: [''],
      bevQuantitytxt: [''],
      bevTotaltxt: [''],
      chkfood: [''],
      checkOutDate: ['', [Validators.required]],
      days: ['']

    });

  }

  onSearchCheckIn(mobileNum) {
    this.b.getBookingDetails().subscribe((data) => {
      debugger;
      const filters = { mobileNo: mobileNum, bookingStatus: 'Booked' };
      const filteredArray = data.filter(item => Object.keys(filters).every(key => item[key] == filters[key]))
      if (filteredArray.length > 0) {
        this.book.fullName = filteredArray[0].fullName;
        this.book.mobileNo = filteredArray[0].mobileNo;
        this.book.checkIn = filteredArray[0].checkIn;
        this.book.id = filteredArray[0].id;
      }
      else {
        alert('No booking found for Mobile No - ' + mobileNum);
      }
    })
  }

  onCheckInSave(checkInValues) {
    debugger;
    checkInValues.checkIn = this.datepipe.transform(checkInValues.checkIn, 'dd/MM/YYYY');
    checkInValues.bookingStatus = "CheckedIn";
    this.b.updateBookingData(checkInValues).subscribe();
    alert('Saved Successfully');
    this.router.navigate(['/home']);
  }

  checkoutform: FormGroup;
  searchForm: FormGroup;
  mobileno: string;
  booking: Booking[] = [];
  finalBooking: Booking[] = [];
  isShow: boolean = false
  foodPrice: number
  quantity: number
  isdisabled: true;
  roomrate: number;
  totalAmount: number;
  finalTotal: number;
  isFood: boolean = false;
  bevragePrice: number;
  bevQuantity: number;
  bevTotal: number;
  isBevrage: boolean = false;
  foodTotal: number;
  checkOutdate: string;
  noofStayDays: number;
  checkInDate: string;
  bookingDetails: Booking;
  rooms: Room;


  onSearch(mobileno: string) {
    this.isShow = true;
    this.cs.getAllCustomerData().subscribe({
      next: (_booking) => {
        this.booking = _booking;
        this.finalBooking;

        for (let obj of this.booking) {
          this.finalBooking = this.booking.filter(x => x.mobileNo === parseInt(this.mobileno) && x.bookingStatus == "CheckedIn");
          this.bookingDetails = this.finalBooking[0];
        }
        console.log(this.finalBooking);

        this.checkoutform.controls['fullName'].setValue(this.finalBooking[0].fullName);
        this.checkoutform.controls['mobileNo'].setValue(this.finalBooking[0].mobileNo);
        this.checkoutform.controls['roomName'].setValue(this.finalBooking[0].roomName);
        this.checkoutform.controls['roomType'].setValue(this.finalBooking[0].roomType);
        this.checkoutform.controls['checkIn'].setValue(this.finalBooking[0].checkIn);
        this.checkoutform.controls['roomNo'].setValue(this.finalBooking[0].roomNo);
        this.checkoutform.controls['price'].setValue(this.finalBooking[0].price);
        this.totalAmount = this.finalBooking[0].price;
        this.checkInDate = this.finalBooking[0].checkIn;

      }
    });


  }
  onfoodchange() {

    if (this.foodPrice == null) {
      //this.foodTotal=0
      this.totalAmount = Number.parseInt(this.totalAmount.toString()) -
        Number.parseInt(this.foodTotal.toString())
      this.foodTotal = 0
    }
    else {
      this.foodTotal = (Number.parseInt(this.foodPrice.toString()) * Number.parseInt(this.quantity.toString()))
      this.totalAmount = (Number.parseInt(this.foodPrice.toString()) * Number.parseInt(this.quantity.toString())) + Number.parseInt(this.totalAmount.toString())

    }

  }
  onchangeQuantity() {
    this.totalAmount = (Number.parseInt(this.foodPrice.toString()) * Number.parseInt(this.quantity.toString()))
      + Number.parseInt(this.totalAmount.toString()) - Number.parseInt(this.foodPrice.toString())

    this.foodTotal = (Number.parseInt(this.foodPrice.toString()) * Number.parseInt(this.quantity.toString()));
    //this.totalAmount+=(Number.parseInt(this.foodTotal.toString()))-(Number.parseInt(this.foodPrice.toString()))
  }
  checkFood() {
    if (this.checkoutform.controls['chkfood'].value == true) {
      this.isFood = true;
    }
    else {
      this.isFood = false;

      this.totalAmount = Number.parseInt(this.totalAmount.toString()) - (Number.parseInt(this.foodPrice.toString()) * Number.parseInt(this.quantity.toString()));

      this.foodPrice = 0
      this.quantity = 0;
      this.foodTotal = 0;
    }

  }
  checkBeverage() {

    if (this.checkoutform.controls['chkBev'].value == true) {
      this.isBevrage = true;
      console.log("beverage" + this.checkoutform.controls['chkBev'].value)
    }
    else {
      this.isBevrage = false;

      this.totalAmount = Number.parseInt(this.totalAmount.toString()) - (Number.parseInt(this.bevragePrice.toString()) * Number.parseInt(this.bevQuantity.toString()));
      this.bevragePrice = 0
      this.bevQuantity = 0;
      this.bevTotal = 0;
    }

  }
  onBevragechange() {
    console.log(this.bevragePrice);
    console.log(this.totalAmount);
    this.totalAmount = Number.parseInt(this.bevragePrice.toString()) + Number.parseInt(this.totalAmount.toString())
    this.bevTotal = (Number.parseInt(this.bevragePrice.toString()) * Number.parseInt(this.bevQuantity.toString()));

  }
  onchangeBevrageQuantity() {
    this.totalAmount = (Number.parseInt(this.bevragePrice.toString()) * Number.parseInt(this.bevQuantity.toString())) + Number.parseInt(this.totalAmount.toString()) - Number.parseInt(this.bevragePrice.toString())
    this.bevTotal = (Number.parseInt(this.bevragePrice.toString()) * Number.parseInt(this.bevQuantity.toString()))
  }
  dayCalculation() {
    const chkoutDate = new Date(this.checkOutdate);

    var splitted = this.checkInDate.split('/', 1);

    console.log(splitted[0])

    this.noofStayDays = chkoutDate.getDate() - Number.parseInt(splitted[0]);

    console.log(this.noofStayDays);
  }

  checkOut() {
    debugger;
    this.cs.getRoomByID(this.bookingDetails.roomNo).subscribe((data) => {
      this.rooms = data;
      this.rooms.status = 0;
      this.cs.updateRoomById(this.rooms, this.bookingDetails.roomNo).subscribe()

    })


    //this.bookingDetails=this.checkoutform;
    this.bookingDetails.checkOut = this.checkoutform.controls['checkOutDate'].value
    this.bookingDetails.noOfStayDays = this.checkoutform.controls['days'].value
    this.bookingDetails.foodTotal = this.checkoutform.controls['foodTotaltxt'].value
    this.bookingDetails.beverageTotal = this.checkoutform.controls['bevTotaltxt'].value
    this.bookingDetails.totalBill = this.checkoutform.controls['total'].value
    this.bookingDetails.bookingStatus = "CheckedOut"
    console.log(this.bookingDetails);
    if (this.checkoutform.valid) {

      this.b.updateBookingCheckout(this.bookingDetails, this.bookingDetails.id.toString()).subscribe();
      alert("CheckOut Successfully")
      window.location.reload();

     }

  
  }
}
