import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import jsPDF from 'jspdf';
import { BilingserviceService } from '../bilingservice.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { hotels } from 'src/hotels';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {

  Id:string|undefined|null;
  @ViewChild('content',{static:false})el!:ElementRef;

  hotel:Array<any>=[];
  http: any;
  constructor(private bilingservice:BilingserviceService, private activatedRoute:ActivatedRoute,http:HttpClient,private formBuilder:FormBuilder){}
  
  formValue!: FormGroup; 
  data:any;
  bookingId:any;
  ngOnInit(): void {
    
    this.formValue = this.formBuilder.group({
      bookingId:[''],
      hotelName:[''],

    
    })
   this.getHotel();
   //gethotelById();
  }
  
  url:string = " http://localhost:3000/saveBookingDetails";
  
  getHotel(){
  this.bilingservice.gethotel().subscribe({
    next:(pre)=>{
      pre.forEach((element:any) => {
        if(element.bookingId==1){
          console.log(element);
          this.hotel.push(element);
        }
      })

  },})


// this.id = this.activatedRoute.snapshot.params['id'];
// this.gethotelById();

}
gethotelById(){
  this.bilingservice.gethotelById(this.bookingId).subscribe(data=>{
    this.data=data;
    console.log(data)
  })
}

  makePDF(){
    let pdf = new jsPDF('p','pt','a4');
    pdf.html(this.el.nativeElement,{
      callback:(pdf)=>{
        pdf.save("demo.pdf");
      }
    });

    
    
}



}



