import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component'
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {
  loginForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private ac: AppComponent, public authService: AuthService) { }

  validation_messages = {
    'username': [
      { type: 'required', message: 'Username is required' },
    ],
    'password': [
      { type: 'required', message: 'Pasword is required' },
    ]
  };

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: new FormControl('', Validators.compose([
        Validators.required
      ])),
      password: new FormControl('', Validators.compose([
        Validators.required
      ]))
    });
  }

  // goToItems() {
  //   this.router.navigate(['/registration-form']);
  //   this.ac.loginSuccessfull = false;
  //   this.ac.registerSuccessfull = true;
  //   window.location.reload();
  // }

  onSubmitLoginDetails(value) {
    if (this.loginForm.valid) {
      if (value.username == "admin" && value.password == "Admin@123") {
        alert('Login Successfully');
        this.router.navigate(['/Dummy']);
      }
      else {
        const { email, password } = this.loginForm.value;
        this.authService.login(email, password).pipe(
        ).subscribe(() => {
        })
        this.ac.loginSuccessfull = false;
        this.ac.UserDashboard = true;
        this.router.navigate(['../home']);
      }
    }
  }

  getRegistrationForm() {
    this.ac.loginSuccessfull = false;
    this.ac.registerSuccessfull = true;
  }

}
