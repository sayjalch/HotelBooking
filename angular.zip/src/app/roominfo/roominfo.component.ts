import { Component,OnInit} from '@angular/core';
import { AdminserviceService } from '../adminservice.service';

@Component({
  selector: 'app-roominfo',
  templateUrl: './roominfo.component.html',
  styleUrls: ['./roominfo.component.css']
})
export class RoominfoComponent implements OnInit {

  roomsdata !:any;
  constructor(private api:AdminserviceService){}
  ngOnInit(): void {
this.getAllRoomsInfo();
  }

  getAllRoomsInfo(){
    this.api.getRoomsInfo()
    .subscribe(res=>{
      
      this.roomsdata = res;
      if(this.roomsdata.status.value==0)
     {
        alert('its Availabale')
      }
    })
  }
}
