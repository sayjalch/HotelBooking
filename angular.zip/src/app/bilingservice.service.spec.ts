import { TestBed } from '@angular/core/testing';

import { BilingserviceService } from './bilingservice.service';

describe('BilingserviceService', () => {
  let service: BilingserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BilingserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
