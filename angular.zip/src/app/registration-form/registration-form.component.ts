import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { CommonServiceService } from '../common-service.service';
import { Registration } from 'src/model/registration';
import { DatePipe } from '@angular/common'
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component'
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent {

  reg = new Registration();
  registrationForm!: FormGroup;

  genders = [
    'Male',
    'Female'
  ];

  validation_messages = {
    'fullname': [
      { type: 'required', message: 'Full name is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'username': [
      { type: 'required', message: 'Username is required' }
    ],
    'gender': [
      { type: 'required', message: 'Please select your gender' }
    ],
    'dateofbirth': [
      { type: 'required', message: 'Please select your birthday' }
    ],
    'phone': [
      { type: 'required', message: 'Mobile no is required' },
      { type: 'maxlength', message: 'Mobile no should be 10 digits long' }
    ],
    'email': [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Enter a valid mail' }
    ],
    'password': [
      { type: 'required', message: 'Pasword is required' },
      { type: 'minlength', message: 'Password must be at least 6 characters long' },
      { type: 'maxlength', message: 'Password cannot be more than 32 characters long' },
      { type: 'pattern', message: 'Password must containt at least one uppercase, one lowercase, and one number' }
    ]
  };

  constructor(private fb: FormBuilder, private authService: AuthService, public s: CommonServiceService, public datepipe: DatePipe, private router: Router, private ac: AppComponent) { }

  ngOnInit() {
    this.createForms();
  }

  createForms() {
    // user details form validations
    this.registrationForm = this.fb.group({
      fullname: new FormControl('', Validators.compose([
        Validators.maxLength(32),
        Validators.minLength(6),
        Validators.required
      ])),
      username: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')
      ])),
      dateofbirth: ['', Validators.required],
      gender: new FormControl(this.genders[0], Validators.required),
      phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      password: new FormControl('', Validators.compose([
        Validators.minLength(6),
        Validators.maxLength(12),
        Validators.required,
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')
      ])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))
    });
  }

  getLoginForm() {
    this.router.navigate(['/login-form']);
    this.ac.loginSuccessfull = true;
    this.ac.registerSuccessfull = false;
  }

  onSubmitRegistrationDetails(value) {
    if (this.registrationForm.valid) {
      value.dateofbirth = this.datepipe.transform(value.dateofbirth, 'dd/MM/YYYY');
      const { name, email, password } = this.registrationForm.value;

      this.authService.signup(name, email, password).subscribe(() => {
        this.router.navigate(['/login']);
      })
      alert('Data Saved Successfully');
      window.location.reload();
    }
  }

}
