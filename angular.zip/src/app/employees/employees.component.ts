import { Component,OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { AdminserviceService } from '../adminservice.service';
import { EmployeeModel } from './employee.model';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  formvalue!:FormGroup;

  employeedata !:any;
  employeeModelobj:EmployeeModel=new EmployeeModel();

  namepattern!:"^[A-Za-z][A-Za-z0-9_]{2,29}$";
  router: any;

  constructor(private formbuilder:FormBuilder, private api:AdminserviceService){}

  ngOnInit(): void {
    this.formvalue=this.formbuilder.group ({
      fname:['',[Validators.required,Validators.pattern(this.namepattern)]],
      lname:['',[Validators.required,Validators.pattern(this.namepattern)]],
      mobile:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
      address:['',[Validators.required]],
      Designation:['',[Validators.required]],
     })
     this.getAllEmployee();
  }

  getAllEmployee(){
    this.api.getEmployee()
    .subscribe(res=>{
      this.employeedata = res;
    })
  }
  postEmployeeDetails(){
    this.employeeModelobj.fname=this.formvalue.value.fname;
    this.employeeModelobj.lname=this.formvalue.value.lname;
    this.employeeModelobj.mobile=this.formvalue.value.mobile;
    this.employeeModelobj.address=this.formvalue.value.address;
    this.employeeModelobj.Designation=this.formvalue.value.Designation;

    this.api.postEmployee(this.employeeModelobj)
    .subscribe(res=>{
      console.log(res);
      alert("Employee Added Successfully")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getAllEmployee();
    })

  }
  
  deletedEmployee(row:any)
  {
this.api.deleteEmployee(row.id)
.subscribe(res=>{
alert("Employee Deleted");
this.getAllEmployee();
})
  }
  onEdit(row:any){
    this.employeeModelobj.id=row.id;
    this.formvalue.controls['fname'].setValue(row.fname);
    this.formvalue.controls['lname'].setValue(row.lname);
    this.formvalue.controls['mobile'].setValue(row.mobile);
    this.formvalue.controls['address'].setValue(row.address);
    this.formvalue.controls['Designation'].setValue(row.Designation);
  }
  updateEmployeeDetails(){
    this.employeeModelobj.fname=this.formvalue.value.fname;
    this.employeeModelobj.lname=this.formvalue.value.lname;
    this.employeeModelobj.mobile=this.formvalue.value.mobile;
    this.employeeModelobj.address=this.formvalue.value.address;
    this.employeeModelobj.Designation=this.formvalue.value.Designation;
    this.api.updateEmployee(this.employeeModelobj.id,this.employeeModelobj,)
    .subscribe(res=>{
      alert("Updated Successfully")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getAllEmployee();
    })
  }
}
