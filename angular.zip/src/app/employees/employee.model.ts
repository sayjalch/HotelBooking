export class EmployeeModel{
    id:number=0;
    fname:string='';
    lname:string='';
    mobile:string='';
    address:string='';
    Designation:string='';
}