export class Registration {
    id:number;
    Fullname:string;
    Username:string;
    EmailId:string;
    Password:string;
    Gender:string;
    DataofBirth:string;
    MobileNo:number;
}