export class Hotel{
id:number;
hotelName:string;
location:string;
image:string;
rate:number;
policyDescription:string;
}