export class Room
{
    id:number;
    roomName:string;
    roomType:string;
    location:string;
    image:string;
    hotelId:number;
    description:string;
    price:number;
    bedImages:string;
    status:number
   

}